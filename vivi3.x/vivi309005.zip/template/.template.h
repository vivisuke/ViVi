//----------------------------------------------------------------------
//
//			File:			"%FileName%"
//			Created:		%Date%
//			Author:			%UserName%
//			Description:
//
//----------------------------------------------------------------------

#pragma once

#ifndef		_HEADER_%FileNameNoExtUpper%_H
#define		_HEADER_%FileNameNoExtUpper%_H



#endif		//_HEADER_%FileNameNoExtUpper%_H
