/**
 *
 *
 * @auther	%UserName%
 * @version %Date%
 */
public class %FileNameNoExt% {

	public %FileNameNoExt%() {
		this();
	}
}
